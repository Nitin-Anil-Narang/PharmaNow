import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class CartProvider with ChangeNotifier {
  Map<String, int> _cartItems = {};
  double _totalPrice = 0.0;

  Map<String, int> get cartItems => _cartItems;
  double get totalPrice => _totalPrice;

  // API endpoint to get the user's cart data
  Future<void> fetchCart(String token) async {
    final url = Uri.parse('http://192.168.29.94:4000/getcart');
    final response = await http.post(
      url,
      headers: {
        'auth-token': token,
      },
    );

    if (response.statusCode == 200) {
      final responseData = json.decode(response.body);
      _cartItems = Map<String, int>.from(responseData);
      _calculateTotalPrice();
      notifyListeners();
    }
  }

  // Adding item to the cart
  Future<void> addItemToCart(String itemId, String token) async {
    final url = Uri.parse('http://192.168.29.94:4000/addtocart');
    await http.post(
      url,
      headers: {
        'auth-token': token,
      },
      body: json.encode({
        'itemId': itemId,
      }),
    );
    _cartItems[itemId] = (_cartItems[itemId] ?? 0) + 1;
    _calculateTotalPrice();
    notifyListeners();
  }

  // Removing item from the cart
  Future<void> removeItemFromCart(String itemId, String token) async {
    final url = Uri.parse('http://192.168.29.94:4000/removefromcart');
    await http.post(
      url,
      headers: {
        'auth-token': token,
      },
      body: json.encode({
        'itemId': itemId,
      }),
    );
    if (_cartItems[itemId]! > 0) {
      _cartItems[itemId] = _cartItems[itemId]! - 1;
    }
    _cartItems.remove(itemId);
    _calculateTotalPrice();
    notifyListeners();
  }
  Future<void> clearCart(String token) async {
    
    _cartItems.clear(); // Clears the cart in the local state
    _totalPrice = 0.0; // Reset the total price
    notifyListeners();
  }

  // Calculate total price from cart
  void _calculateTotalPrice() {
    _totalPrice = 0.0;

    // _totalPrice = 0.0;
    _cartItems.forEach((
      itemId,
      quantity,
    ) {
      _totalPrice += quantity *
          100; // For now, assuming each item costs 100 for simplicity
    });
  }
}
  // void _calculateTotalPrice() {
  //   double total = 0.0;
  //   _cartItems.forEach((itemId, quantity) {
  //     // Fetch product details based on itemId
  //     final product = ProductProvider().getProductById(itemId);
  //     print(product);
  //     if (product != null) {
  //       total += product.price * quantity;
  //     }
  //   });
  //   _totalPrice = total;
  // }
