import 'package:flutter/material.dart';
import 'package:pharmacy/home_upgrade.dart';
import 'package:pharmacy/login_page.dart';
import 'package:pharmacy/sign_up.dart';
import 'package:pharmacy/splash_screen.dart';
import 'package:pharmacy/user_provider.dart';
import 'package:provider/provider.dart';
import 'cart_provider.dart';
import 'product_provider.dart';
import 'product_page.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatefulWidget {
  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  String? token;

  @override
  void initState() {
    super.initState();
    _loadToken();
  }

  Future<void> _loadToken() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      token = prefs.getString('auth-token'); // Load saved token
    });
  }

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (ctx) => ProductProvider()),
        ChangeNotifierProvider(create: (ctx) => CartProvider()),
        ChangeNotifierProvider(create: (ctx) => UserProvider()),
      ],
      child: MaterialApp(
        title: 'Pharmacy',
        theme: ThemeData(
          primarySwatch: Colors.blue,
        ),
        debugShowCheckedModeBanner: false,
        home: token == null ? SplashScreen() : ProductPages(token: token!),
        routes: {
          // '/': (context) => SplashScreen(),
          '/login': (context) => LoginPage(),
          '/signup': (context) => SignUpPage(),
          '/home': (context) => ProductPages(token: token.toString()),
          '/products': (context) => ProductPage(token: token.toString())
        },
      ),
    );
  }
}
