import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class UserProvider with ChangeNotifier {
  String _username = '';
  String _email = '';

  String get username => _username;
  String get email => _email;

  Future<void> fetchUserDetails(token) async {
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('auth-token');

    if (token == null) {
      print("No token found, user not logged in.");
      return;
    }

    final url = Uri.parse('http://192.168.29.94:4000/getuser');
    final response = await http.get(
      url,
      headers: {'auth-token': token}, // Send token in headers
    );

    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      _username = data['username'];
      _email = data['email'];
      notifyListeners();
      print(_username);
      print(_email);
    } else {
      print("Failed to fetch user details");
    }
  }
}
