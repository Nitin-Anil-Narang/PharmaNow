import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:pharmacy/cart_page.dart';
import 'package:pharmacy/product_detail.dart';
import 'package:provider/provider.dart';
import 'product_provider.dart';
import 'cart_provider.dart';

class ProductPages extends StatefulWidget {
  final String token;

  const ProductPages({required this.token});

  @override
  _ProductPageStates createState() => _ProductPageStates();
}

class _ProductPageStates extends State<ProductPages> {
  @override
  Widget build(BuildContext context) {
    final productProvider = Provider.of<ProductProvider>(context);

    // Function to handle logout
    void logout() {
      // You can clear the user token, clear local storage, or navigate to the login screen.
      Navigator.pushReplacementNamed(
          context, '/login'); // Assuming you have a login screen route
    }

    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Products",
          style: TextStyle(fontSize: 30),
        ),
        backgroundColor: Colors.blueAccent,
        actions: [
          IconButton(
            icon: Icon(Icons.shopping_cart),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (ctx) => CartPage(token: widget.token),
                ),
              );
            },
          ),
        ],
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            // User Logo and Info
            UserAccountsDrawerHeader(
              accountName: Text("User Name"), // Replace with actual user name
              accountEmail: Text("user@example.com"),
              decoration: BoxDecoration(
                color: Colors.blueAccent, // Set background color to blue
              ),
              // Replace with actual email
              currentAccountPicture: CircleAvatar(
                backgroundColor: Colors.white,
                child: Icon(
                  Icons.person,
                  size: 40,
                  color: Colors.blue,
                ),
              ),
              arrowColor: Colors.blueAccent,
            ),
            // Logout Button
            ListTile(
              leading: Icon(Icons.logout),
              title: Text("Logout"),
              onTap: logout, // Trigger logout functionality
            ),
          ],
        ),
      ),
      body: FutureBuilder(
        future: productProvider.fetchProducts(),
        builder: (ctx, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return Center(child: Text("Error: ${snapshot.error}"));
          }

          // Get the last 4 products from the list (most recent ones)
          List recentProducts = List.from(productProvider.products);
          recentProducts = recentProducts.length > 6
              ? recentProducts.sublist(recentProducts.length - 4)
              : recentProducts;

          // If less than 4, take all products

          return Column(
            children: [
              // Color Card with Text about Medicine

              Expanded(
                flex: 8,
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: SizedBox(
                    height: 300,
                    child: Card(
                      color: Colors.blueAccent, // Card background color
                      shape: RoundedRectangleBorder(
                        borderRadius:
                            BorderRadius.circular(10), // Rounded corners
                      ),
                      elevation: 5, // Shadow effect for the card
                      child: Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: Column(
                          // verticalDirection: VerticalDirection.up,
                          // crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            SizedBox(
                              // width: 600,
                              height: 120,
                              child: Image.network(
                                'https://achievece.com/_next/image?url=https://images.ctfassets.net/3cze0entj8bw/7wtcdGmMyxEhCrrVgA6Z9S/0c28e829bd11a34c32903222d988fea1/The_Opioid_Epidemic_Searching_for_Solutions.jpg&w=3840&q=75',
                                fit: BoxFit.contain,
                              ),
                            ),
                            SizedBox(
                              height: 20,
                            ),
                            Text(
                              "Medicines for All Your Health Needs",
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: Colors.white,
                              ),
                            ),
                            SizedBox(height: 10),
                            Text(
                              "Find the best medicines from trusted brands. We offer a wide variety of health products to keep you in top condition.",
                              style: TextStyle(
                                fontSize: 14,
                                color: Colors.white,
                              ),
                              textAlign: TextAlign.center,
                            )
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              Center(
                child: Text(
                  "Most Recent Products",
                  style: TextStyle(fontSize: 25),
                ),
              ),

              // Product grid
              Expanded(
                flex: 9,
                child: GridView.builder(
                  itemCount: recentProducts.length,
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2, // 2 products per row
                    crossAxisSpacing: 40.0, // Space between columns
                    mainAxisSpacing: 10.0,
                    mainAxisExtent: 300, // Space between rows
                    childAspectRatio: 1, // Aspect ratio of the image (square)
                  ),
                  padding: EdgeInsets.all(10.0),
                  itemBuilder: (ctx, index) {
                    final product = recentProducts[index];
                    String desc = product.description.length > 50
                        ? product.description.substring(0, 40) + '...'
                        : product.description;
                    return GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context,
                          PageRouteBuilder(
                            transitionDuration: Duration(milliseconds: 500),
                            opaque: false, // Allows transparency
                            pageBuilder: (context, animation,
                                    secondaryAnimation) =>
                                ProductDetailPage(
                                    product: product, token: widget.token),
                            transitionsBuilder: (context, animation,
                                secondaryAnimation, child) {
                              return Stack(
                                children: [
                                  BackdropFilter(
                                    filter: ImageFilter.blur(
                                        sigmaX: 5, sigmaY: 5), // Apply blur
                                    child: Container(
                                        color: Colors.black.withOpacity(0.1)),
                                  ),
                                  FadeTransition(
                                    opacity: animation,
                                    child: child,
                                  ),
                                ],
                              );
                            },
                          ),
                        );
                      },
                      child: GridTile(
                        child: Column(
                          children: [
                            SizedBox(
                              width: 150.0, // Width of the image
                              height: 150.0,
                              child: Container(
                                decoration: BoxDecoration(
                                  border: Border.all(
                                    color: Colors.grey.shade500,
                                    width: 2,
                                  ),
                                ),
                                child: Image.network(
                                  product.image,
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                            Text(product.name),
                            SizedBox(
                              height: 4,
                            ),
                            Text(
                              desc, // Show product category
                              style:
                                  TextStyle(fontSize: 12, color: Colors.black),
                            ),
                            Text(
                              product.category, // Show product description
                              style:
                                  TextStyle(fontSize: 10, color: Colors.black),
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              children: [
                                Text(
                                  '₹${product.price}',
                                  style: TextStyle(fontSize: 15),
                                ),
                                IconButton(
                                  icon: Icon(
                                    Icons.add_shopping_cart,
                                    size: 35,
                                  ),
                                  onPressed: () {
                                    Provider.of<CartProvider>(context,
                                            listen: false)
                                        .addItemToCart(
                                            product.id, widget.token);
                                    // Navigator.push(
                                    //   context,
                                    //   MaterialPageRoute(
                                    //     builder: (context) => ProductDetailPage(
                                    //         product: product,
                                    //         token: widget.token),
                                    //   ),
                                    // );
                                  },
                                ),
                              ],
                            )
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
              Expanded(
                flex: 2,
                child: TextButton(
                    onPressed: () {
                      Navigator.pushNamed(context, '/products');
                    },
                    style: TextButton.styleFrom(minimumSize: Size(50, 50)),
                    child: Center(
                        child: Text(
                      "Explore Products",
                      style: TextStyle(fontSize: 20, color: Colors.black),
                    ))),
              )
              // child: GestureDetector(
              //     onTap: () {
              //       Navigator.pushNamed(context, '/products');
              //     },
              //     child: Text("Explore Product",)))
            ],
          );
        },
      ),
    );
  }
}
