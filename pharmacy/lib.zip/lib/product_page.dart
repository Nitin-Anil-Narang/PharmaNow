import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:pharmacy/cart_page.dart';
import 'package:pharmacy/product_detail.dart';
import 'package:provider/provider.dart';
import 'product_provider.dart';
import 'cart_provider.dart';

class ProductPage extends StatefulWidget {
  final String token;

  const ProductPage({required this.token});

  @override
  _ProductPageState createState() => _ProductPageState();
}

class _ProductPageState extends State<ProductPage> {
  String selectedCategory = 'All'; // Default category

  @override
  Widget build(BuildContext context) {
    final productProvider = Provider.of<ProductProvider>(context);

    return Scaffold(
      appBar: AppBar(
        title: Text("Products"),
        backgroundColor: Colors.blueAccent,
        actions: [
          IconButton(
            icon: Icon(Icons.shopping_cart),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (ctx) => CartPage(token: widget.token),
                ),
              );
            },
          ),
        ],
      ),
      body: FutureBuilder(
        future: productProvider.fetchProducts(),
        builder: (ctx, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return Center(child: Text("Error: ${snapshot.error}"));
          }

          // Filter products by the selected category
          List filteredProducts = selectedCategory == 'All'
              ? productProvider.products
              : productProvider.products
                  .where((product) => product.category == selectedCategory)
                  .toList();

          return Column(
            children: [
              // Category buttons
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      CategoryButton(
                        label: 'All',
                        onPressed: () {
                          setState(() {
                            selectedCategory = 'All';
                          });
                        },
                      ),
                      CategoryButton(
                        label: 'Medicine',
                        onPressed: () {
                          setState(() {
                            selectedCategory = 'Medicine';
                          });
                        },
                      ),
                      CategoryButton(
                        label: 'Tools',
                        onPressed: () {
                          setState(() {
                            selectedCategory = 'Tools';
                          });
                        },
                      ),
                      CategoryButton(
                        label: 'Vitamins',
                        onPressed: () {
                          setState(() {
                            selectedCategory = 'Vitamins';
                          });
                        },
                      ),
                    ],
                  ),
                ),
              ),

              // Product grid
              Expanded(
                child: GridView.builder(
                  itemCount: filteredProducts.length,
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2, // 2 products per row
                    crossAxisSpacing: 40.0, // Space between columns
                    mainAxisSpacing: 10.0,
                    mainAxisExtent: 320, // Space between rows
                    childAspectRatio:
                        (1 / .4), // Aspect ratio of the image (square)
                  ),
                  padding: EdgeInsets.all(10.0),
                  itemBuilder: (ctx, index) {
                    final product = filteredProducts[index];
                    String desc = product.description.length > 40
                        ? product.description.substring(0, 40) + '...'
                        : product.description;
                    return GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context,
                          PageRouteBuilder(
                            transitionDuration: Duration(milliseconds: 500),
                            opaque: false, // Allows transparency
                            pageBuilder: (context, animation,
                                    secondaryAnimation) =>
                                ProductDetailPage(
                                    product: product, token: widget.token),
                            transitionsBuilder: (context, animation,
                                secondaryAnimation, child) {
                              return Stack(
                                children: [
                                  BackdropFilter(
                                    filter: ImageFilter.blur(
                                        sigmaX: 5, sigmaY: 5), // Apply blur
                                    child: Container(
                                        color: Colors.black.withOpacity(0.1)),
                                  ),
                                  FadeTransition(
                                    opacity: animation,
                                    child: child,
                                  ),
                                ],
                              );
                            },
                          ),
                        );
                      },
                      child: GridTile(
                        child: Column(
                          children: [
                            SizedBox(
                              width: 150.0, // Width of the image
                              height: 150.0,
                              child: Container(
                                decoration: BoxDecoration(
                                  border: Border.all(
                                    color: Colors.grey.shade500,
                                    width: 3,
                                  ),
                                ),
                                child: Image.network(
                                  product.image,
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                            Text(
                              product.name,
                              style: TextStyle(
                                fontSize: 20,
                              ),
                            ),
                            Text(
                              product.category, // Show product category
                              style:
                                  TextStyle(fontSize: 15, color: Colors.grey),
                            ),
                            Text(
                              desc, // Show product description
                              style: TextStyle(
                                  fontSize: 15,
                                  color: Colors.black,
                                  fontWeight: FontWeight.w500),
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceAround,
                              children: [
                                Text(
                                  '₹${product.price}',
                                  style: TextStyle(fontSize: 15),
                                ),
                                IconButton(
                                  icon: Icon(
                                    Icons.add_shopping_cart,
                                    size: 35,
                                  ),
                                  onPressed: () {
                                    Provider.of<CartProvider>(context,
                                            listen: false)
                                        .addItemToCart(
                                            product.id, widget.token);
                                    ScaffoldMessenger.of(context)
                                        .showSnackBar(SnackBar(
                                      content: Text(
                                          '${product.name} added to cart!'),
                                    ));

                                    // Navigator.push(
                                    //   context,
                                    //   MaterialPageRoute(
                                    //     builder: (context) => ProductDetailPage(
                                    //         product: product,
                                    //         token: widget.token),
                                    //   ),
                                    // );
                                  },
                                ),
                              ],
                            )
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class CategoryButton extends StatelessWidget {
  final String label;
  final VoidCallback onPressed;

  const CategoryButton({
    required this.label,
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 5.0),
      child: ElevatedButton(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
          foregroundColor: Colors.white,
          backgroundColor: Colors.blue.shade700, // Text color
        ),
        child: Text(label),
      ),
    );
  }
}
