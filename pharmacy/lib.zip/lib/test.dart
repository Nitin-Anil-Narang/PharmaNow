import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class CartProvider with ChangeNotifier {
  Map<String, int> _cartItems = {};
  double _totalPrice = 0.0;

  Map<String, int> get cartItems => _cartItems;
  double get totalPrice => _totalPrice;

  // API endpoint to get the user's cart data
  Future<void> fetchCart(String token) async {
    final url = Uri.parse('http://localhost:4000/getcart');
    final response = await http.post(
      url,
      headers: {
        'auth-token': token,
      },
    );

    if (response.statusCode == 200) {
      final responseData = json.decode(response.body);
      _cartItems = Map<String, int>.from(responseData);
      _calculateTotalPrice();
      notifyListeners();
    }
  }

  // Adding item to the cart
  Future<void> addItemToCart(String itemId, String token) async {
    final url = Uri.parse('http://localhost:4000/addtocart');
    await http.post(
      url,
      headers: {
        'auth-token': token,
      },
      body: json.encode({
        'itemId': itemId,
      }),
    );
    _cartItems[itemId] = (_cartItems[itemId] ?? 0) + 1;
    _calculateTotalPrice();
    notifyListeners();
  }

  // Removing item from the cart
  Future<void> removeItemFromCart(String itemId, String token) async {
    final url = Uri.parse('http://localhost:4000/removefromcart');
    await http.post(
      url,
      headers: {
        'auth-token': token,
      },
      body: json.encode({
        'itemId': itemId,
      }),
    );
    if (_cartItems[itemId]! > 0) {
      _cartItems[itemId] = _cartItems[itemId]! - 1;
    }
    _cartItems.remove(itemId);
    _calculateTotalPrice();
    notifyListeners();
  }

  // Calculate total price from cart
  // void _calculateTotalPrice() {
  //   _totalPrice = 0.0;

  //   // _totalPrice = 0.0;
  //   _cartItems.forEach((
  //     itemId,
  //     quantity,
  //   ) {
  //     _totalPrice += quantity *
  //         100; // For now, assuming each item costs 100 for simplicity
  //   });
  // }
  void _calculateTotalPrice() {
    _totalPrice = 0.0;

    _cartItems.forEach((itemId, itemData) {
      final quantity = itemData["quantity"];
      final price = itemData['price'];
      _totalPrice += quantity * price;
    });
  }
}
  // void _calculateTotalPrice() {
  //   double total = 0.0;
  //   _cartItems.forEach((itemId, quantity) {
  //     // Fetch product details based on itemId
  //     final product = ProductProvider().getProductById(itemId);
  //     print(product);
  //     if (product != null) {
  //       total += product.price * quantity;
  //     }
  //   });
  //   _totalPrice = total;
  // }











//login 

Future<void> _login() async {
    final email = _emailController.text;
    final password = _passwordController.text;

    if (email.isEmpty || password.isEmpty) {
      setState(() {
        _errorMessage = "Please enter both email and password.";
      });
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = '';
    });

    final url = Uri.parse('http://localhost:4000/login');
    final response = await http.post(
      url,
      headers: {'Content-Type': 'application/json'},
      body: json.encode({
        'email': email,
        'password': password,
      }),
    );

    final responseData = json.decode(response.body);

    if (response.statusCode == 200 && responseData['sucess'] == true) {
      // Store the token or navigate to another page
      final token = responseData['token'];

      // Navigate to the home page or any other page
      Navigator.pushReplacementNamed(context, '/home', arguments: token);
    } else {
      setState(() {
        _errorMessage = responseData['errors'] ?? 'Login failed';
        _isLoading = false;
      });
    }
  }





Future<void> _signup() async {
    final name = _nameController.text;
    final email = _emailController.text;
    final password = _passwordController.text;

    if (name.isEmpty || email.isEmpty || password.isEmpty) {
      setState(() {
        _errorMessage = "Please fill in all fields.";
      });
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = '';
    });

    final url = Uri.parse('http://localhost:4000/signup');
    final response = await http.post(
      url,
      headers: {'Content-Type': 'application/json'},
      body: json.encode({
        'username': name,
        'email': email,
        'password': password,
      }),
    );

    final responseData = json.decode(response.body);

    if (response.statusCode == 200 && responseData['sucess'] == true) {
      // Show success message or navigate to login
      Navigator.pushReplacementNamed(context, '/login');
    } else {
      setState(() {
        _errorMessage = responseData['errors'] ?? 'Signup failed';
        _isLoading = false;
      });
    }
  }
