import 'package:flutter/material.dart';
import 'package:pharmacy/home_upgrade.dart';
import 'package:pharmacy/login_page.dart';
import 'package:pharmacy/sign_up.dart';
import 'package:pharmacy/splash_screen.dart';
import 'package:provider/provider.dart';
import 'cart_provider.dart';
import 'product_provider.dart';
import 'product_page.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  final String token = 'your_user_token'; // Use your token here

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (ctx) => ProductProvider()),
        ChangeNotifierProvider(create: (ctx) => CartProvider()),
      ],
      child: MaterialApp(
        title: 'Pharmacy',
        theme: ThemeData(
          primarySwatch: Colors.blue,
        ),
        debugShowCheckedModeBanner: false,
        routes: {
          '/': (context) => SplashScreen(),
          '/login': (context) => LoginPage(),
          '/signup': (context) => SignUpPage(),
          '/home': (context) => ProductPages(token: token),
          '/products': (context) => ProductPage(token: token)
        },
      ),
    );
  }
}
