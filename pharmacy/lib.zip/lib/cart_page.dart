import 'package:flutter/material.dart';
import 'package:pharmacy/home_upgrade.dart';
import 'package:provider/provider.dart';
import 'package:razorpay_flutter/razorpay_flutter.dart';
import 'cart_provider.dart';
import 'product_provider.dart';

class CartPage extends StatefulWidget {
  final String token;

  CartPage({required this.token});

  @override
  _CartPageState createState() => _CartPageState();
}

class _CartPageState extends State<CartPage> {
  late Razorpay _razorpay;

  @override
  void initState() {
    super.initState();
    _razorpay = Razorpay();

    // Adding event listeners for payment events
    _razorpay.on(Razorpay.EVENT_PAYMENT_SUCCESS, _handlePaymentSuccess);
    _razorpay.on(Razorpay.EVENT_PAYMENT_ERROR, _handlePaymentError);
  }

  @override
  void dispose() {
    super.dispose();
    _razorpay.clear(); // Clean up the Razorpay instance
  }

  // Payment success handler
  void _handlePaymentSuccess(PaymentSuccessResponse response) {
    print("Payment Success: ${response.paymentId}");
    Provider.of<CartProvider>(context, listen: false).clearCart(widget.token);
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(
          builder: (context) => ProductPages(token: widget.token)),
      (route) => false, // Removes all previous routes
    );
    // Handle payment success, e.g., call an API to confirm the payment
  }

  // Payment error handler
  void _handlePaymentError(PaymentFailureResponse response) {
    print("Payment Error: ${response.message}");
    // Show error message to the user
  }

  @override
  Widget build(BuildContext context) {
    final cartProvider = Provider.of<CartProvider>(context);
    final productProvider = Provider.of<ProductProvider>(context);

    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Cart",
          style: TextStyle(fontSize: 30),
        ),
        backgroundColor: const Color.fromRGBO(41, 98, 255, 1),
      ),
      body: FutureBuilder(
        future: cartProvider.fetchCart(widget.token),
        builder: (ctx, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return Center(child: Text("Error: ${snapshot.error}"));
          }

          // Calculate total price for all items in the cart
          double totalPrice = 0.0;
          cartProvider.cartItems.forEach((itemId, quantity) {
            final product = productProvider.products
                .firstWhere((product) => product.id == itemId,
                    orElse: () => Product(
                          id: itemId,
                          name: 'Unknown Product',
                          image: '',
                          price: 0.0,
                          description: '',
                          category: '',
                        ));

            totalPrice += product.price * quantity;
          });

          return Column(
            children: [
              Expanded(
                child: ListView.builder(
                  itemCount: cartProvider.cartItems.length,
                  itemBuilder: (ctx, index) {
                    final itemId = cartProvider.cartItems.keys.toList()[index];
                    final quantity = cartProvider.cartItems[itemId]!;

                    final product = productProvider.products
                        .firstWhere((product) => product.id == itemId,
                            orElse: () => Product(
                                  id: itemId,
                                  name: 'Unknown Product',
                                  image: '',
                                  price: 0.0,
                                  description: '',
                                  category: '',
                                ));

                    return ListTile(
                      leading: Image.network(
                        product.image,
                        width: 50,
                        height: 50,
                        fit: BoxFit.cover,
                      ),
                      title: Text(product.name),
                      subtitle:
                          Text('Quantity: $quantity\nPrice: ₹${product.price}'),
                      trailing: IconButton(
                        icon: Icon(Icons.delete),
                        onPressed: () {
                          cartProvider.removeItemFromCart(itemId, widget.token);
                        },
                      ),
                    );
                  },
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Center(
                      child: Text(
                        'Total: ₹${totalPrice.toStringAsFixed(2)}', // Show calculated total price
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    SizedBox(height: 10),
                    Center(
                      child: ElevatedButton(
                        onPressed: () {
                          _openCheckout(
                              totalPrice); // Proceed to Razorpay checkout
                        },
                        child: Text('Checkout'),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  // Function to trigger Razorpay payment
  void _openCheckout(double totalPrice) {
    var options = {
      'key': 'rzp_test_O5phZVggDClxAj', // Your Razorpay API Key
      'amount': (totalPrice * 100).toInt(), // Convert to paise
      'name': 'Pharmacy',
      'description': 'Payment for Medicine',
      "theme": {
        "color": '#2862ff',
      }
    };

    try {
      _razorpay.open(options); // Open the Razorpay checkout
    } catch (e) {
      print("Error opening Razorpay: $e");
    }
  }
}
