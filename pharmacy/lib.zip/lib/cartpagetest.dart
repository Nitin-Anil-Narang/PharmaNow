import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'cart_provider.dart';
import 'product_provider.dart';

class CartPage extends StatelessWidget {
  final String token;

  CartPage({required this.token});

  @override
  Widget build(BuildContext context) {
    final cartProvider = Provider.of<CartProvider>(context);
    final productProvider = Provider.of<ProductProvider>(context);

    return Scaffold(
      appBar: AppBar(
        title: Text("Cart"),
      ),
      body: FutureBuilder(
        future: cartProvider.fetchCart(token),
        builder: (ctx, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return Center(child: Text("Error: ${snapshot.error}"));
          }

          // Calculate total price for all items in the cart
          double totalPrice = 0.0;
          cartProvider.cartItems.forEach((itemId, quantity) {
            final product = productProvider.products
                .firstWhere((product) => product.id == itemId,
                    orElse: () => Product(
                          id: itemId,
                          name: 'Unknown Product',
                          image: '',
                          price: 0.0, description: '', category: '',
                        ));

            totalPrice += product.price * quantity;
          });

          return Column(
            children: [
              Expanded(
                child: ListView.builder(
                  itemCount: cartProvider.cartItems.length,
                  itemBuilder: (ctx, index) {
                    final itemId = cartProvider.cartItems.keys.toList()[index];
                    final quantity = cartProvider.cartItems[itemId]!;

                    final product = productProvider.products
                        .firstWhere((product) => product.id == itemId,
                            orElse: () => Product(
                                  id: itemId,
                                  name: 'Unknown Product',
                                  image: '',
                                  price: 0.0, 
                                  description: '',
                                  category: '',
                                ));

                    return ListTile(
                      leading: Image.network(
                        product.image,
                        width: 50,
                        height: 50,
                        fit: BoxFit.cover,
                      ),
                      title: Text(product.name),
                      subtitle:
                          Text('Quantity: $quantity\nPrice: ₹${product.price}'),
                      trailing: IconButton(
                        icon: Icon(Icons.delete),
                        onPressed: () {
                          cartProvider.removeItemFromCart(itemId, token);
                        },
                      ),
                    );
                  },
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      'Total: ₹${totalPrice.toStringAsFixed(2)}', // Show calculated total price
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(height: 10),
                    ElevatedButton(
                      onPressed: () {
                        // Implement checkout or payment functionality here
                      },
                      child: Text('Checkout'),
                    ),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}
