import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:dio/dio.dart';
import 'package:http/http.dart' as http;

class ImageUploadScreen extends StatefulWidget {
  @override
  _ImageUploadScreenState createState() => _ImageUploadScreenState();
}

class _ImageUploadScreenState extends State<ImageUploadScreen> {
  File? _image;
  String? _responseMessage;
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _priceController = TextEditingController();
  final TextEditingController _descriptionController = TextEditingController();
  String _selectedCategory = 'Medicine';

  final ImagePicker _picker = ImagePicker();
  final Dio _dio = Dio();

  Future<void> _pickImage() async {
    final pickedFile = await _picker.pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      setState(() {
        _image = File(pickedFile.path);
      });
    }
  }

  Future<void> _uploadImage() async {
    if (_image == null) {
      setState(() {
        _responseMessage = 'Please select an image first!';
      });
      return;
    }

    if (_nameController.text.isEmpty ||
        _priceController.text.isEmpty ||
        _descriptionController.text.isEmpty) {
      setState(() {
        _responseMessage = 'Please provide all details!';
      });
      return;
    }

    const String apiUrl = 'http://192.168.29.94:4000/upload';

    try {
      FormData formData = FormData.fromMap({
        'product': await MultipartFile.fromFile(_image!.path),
      });

      var response = await _dio.post(apiUrl, data: formData);

      if (response.statusCode == 200) {
        setState(() {
          _responseMessage = 'Upload Successful: ${response.data}';
        });
        try {
          final uri = Uri.parse('http://192.168.29.94:4000/addproduct');
          var data = response.data;

          final Map<String, String> productData = {
            'name': _nameController.text,
            'new_price': _priceController.text,
            'description': _descriptionController.text,
            'category': _selectedCategory,
            'image': data['image_url'],
          };
          print(productData);

          final response1 = await http.post(
            uri,
            headers: {'Content-Type': 'application/json'},
            body: json.encode(productData),
          );

          if (response1.statusCode == 200) {
            ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Product added successfully!')));
            Navigator.pushNamed(context, '/');
          } else {
            ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Failed to add product!')));
          }
        } catch (e) {
          setState(() {
            _responseMessage = 'Error: $e';
          });
        }
      } else {
        setState(() {
          _responseMessage = 'Upload Failed: ${response.statusCode}';
        });
      }
    } catch (e) {
      setState(() {
        _responseMessage = 'Error: $e';
      });
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    _priceController.dispose();
    _descriptionController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade300,
      appBar: AppBar(title: Text('Image Upload Demo')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            _image == null ? Text('No image selected.') : Image.file(_image!),
            SizedBox(height: 20),
            ElevatedButton(onPressed: _pickImage, child: Text('Select Image')),
            SizedBox(height: 20),
            TextField(
              controller: _nameController,
              decoration: InputDecoration(
                labelText: 'Product Name',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 10),
            TextField(
              controller: _priceController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: 'Product Price',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 10),
            TextField(
              controller: _descriptionController,
              decoration: InputDecoration(
                labelText: 'Product Description',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 10),
            DropdownButtonFormField<String>(
              value: _selectedCategory,
              items: ['Medicine', 'Tools', 'Vitamins']
                  .map((category) => DropdownMenuItem(
                        value: category,
                        child: Text(category),
                      ))
                  .toList(),
              onChanged: (value) {
                setState(() {
                  _selectedCategory = value!;
                });
              },
              decoration: InputDecoration(
                labelText: 'Select Category',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 20),
            ElevatedButton(
                onPressed: _uploadImage, child: Text('Upload Image')),
            SizedBox(height: 20),
            _responseMessage == null
                ? Container()
                : Text(
                    _responseMessage!,
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 16, color: Colors.blue),
                  ),
          ],
        ),
      ),
    );
  }
}
