import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class ProductListScreen extends StatefulWidget {
  @override
  _ProductListScreenState createState() => _ProductListScreenState();
}

class _ProductListScreenState extends State<ProductListScreen> {
  List<dynamic> productList = []; // Local product list for UI updates

  @override
  void initState() {
    super.initState();
    fetchProducts(); // Load products when screen initializes
  }

  /// Fetches products from the backend API
  Future<void> fetchProducts() async {
    const String apiUrl = 'http://192.168.29.94:4000/allproduct';

    try {
      final response = await http.get(Uri.parse(apiUrl));

      if (response.statusCode == 200) {
        var data = json.decode(response.body);
        // Replace 'localhost', '127.0.0.1' or '192.168.x.x' with '10.0.2.2' in the product data
        if (Platform.isAndroid) {
          // Replace 'localhost', '127.0.0.1' or '192.168.x.x' with '10.0.2.2' for Android devices
          for (var product in data) {
            if (product['image'] != null &&
                product['image'].contains('localhost')) {
              product['image'] =
                  product['image'].replaceAll('localhost', '10.0.2.2');
            }
            if (product['image'] != null &&
                product['image'].contains('127.0.0.1')) {
              product['image'] =
                  product['image'].replaceAll('127.0.0.1', '10.0.2.2');
            }
            if (product['image'] != null &&
                product['image'].contains('192.168')) {
              product['image'] = product['image']
                  .replaceAll(RegExp(r'192\.168\.\d+\.\d+'), '10.0.2.2');
            }
          }
        }
        if (mounted) {
          setState(() {
            productList = data; // Update product list
          });
        }
      } else {
        throw Exception('Failed to load products');
      }
    } catch (e) {
      print("Error fetching products: $e");
    }
  }

  /// Removes a product from the backend and updates UI
  Future<void> removeProduct(int index, int id, String productId) async {
    final String apiUrl = 'http://192.168.29.94:4000/removeproduct';
    print(index);
    print(productId);

    try {
      final response = await http.post(
        Uri.parse(apiUrl),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({"id": id, "name": productId}),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['sucess'] == true) {
          print("Product removed successfully: ${data['name']}");
          setState(() {
            productList.removeAt(index); // Remove from UI
          });
        } else {
          print("Failed to remove product");
        }
      } else {
        print("Error: ${response.statusCode}");
      }
    } catch (e) {
      print("Exception: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade300,
      appBar: AppBar(title: Text('Product List')),
      body: productList.isEmpty
          ? Center(child: Text('No products found.'))
          : ListView.builder(
              itemCount: productList.length,
              itemBuilder: (context, index) {
                var product = productList[index];
                int id = product['id'] ?? null;
                String name = product['name'] ?? 'No Name';
                double price = product['new_price']?.toDouble() ?? 0.0;
                String imageUrl = product['image'] ?? '';

                return Card(
                  margin: EdgeInsets.all(8.0),
                  child: ListTile(
                    leading: imageUrl.isNotEmpty
                        ? Image.network(imageUrl,
                            width: 50, height: 50, fit: BoxFit.cover)
                        : Icon(Icons.image, size: 50),
                    title: Text(name),
                    subtitle: Text('₨ ${price.toStringAsFixed(2)}'),
                    trailing: IconButton(
                      icon: Icon(Icons.delete, color: Colors.red),
                      onPressed: () => removeProduct(index, id, name),
                    ),
                  ),
                );
              },
            ),
    );
  }
}

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: ProductListScreen(),
  ));
}
