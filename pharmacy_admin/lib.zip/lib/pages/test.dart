import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class ProductListScreen extends StatefulWidget {
  const ProductListScreen({super.key});

  @override
  _ProductListScreenState createState() => _ProductListScreenState();
}

class _ProductListScreenState extends State<ProductListScreen> {
  late Future<List<dynamic>> products;
  

  // Fetch products from the API as raw JSON
  Future<List<dynamic>> fetchProducts() async {
    const String apiUrl = 'http://192.168.29.94:4000/allproduct';
    //192.168.29.94
    //127.0.0.1

    try {
      final response = await http.get(Uri.parse(apiUrl));

      if (response.statusCode == 200) {
        // Parse the response as raw JSON
        // return json.decode(response.body);
        // Returns a List<dynamic> of product data
        // Parse the response body as raw JSON
        var productList = json.decode(response.body);

        // Replace 'localhost', '127.0.0.1' or '192.168.x.x' with '10.0.2.2' in the product data
        if (Platform.isAndroid) {
          // Replace 'localhost', '127.0.0.1' or '192.168.x.x' with '10.0.2.2' for Android devices
          for (var product in productList) {
            if (product['image'] != null &&
                product['image'].contains('localhost')) {
              product['image'] =
                  product['image'].replaceAll('localhost', '10.0.2.2');
            }
            if (product['image'] != null &&
                product['image'].contains('127.0.0.1')) {
              product['image'] =
                  product['image'].replaceAll('127.0.0.1', '10.0.2.2');
            }
            if (product['image'] != null &&
                product['image'].contains('192.168')) {
              product['image'] = product['image']
                  .replaceAll(RegExp(r'192\.168\.\d+\.\d+'), '10.0.2.2');
            }
          }
        }

        return productList;
      } else {
        throw Exception('Failed to load products');
      }
    } catch (e) {
      throw Exception('Error fetching products: $e');
    }
  }

  Future<void> removeProduct(int index, String productName) async {
    final String apiUrl = 'http://192.168.29.94:4000/removeproduct';
    print(index);
    print(productName);

    try {
      final response = await http.post(
        Uri.parse(apiUrl),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({"id": index, "name": productName}),
      );
      print(index);

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['sucess'] == true) {
          print("Product removed successfully: ${data['name']}");
          setState(() {
            products.removeAt(index);
          });
          // Update the UI by removing the item from the list
        } else {
          print("Failed to remove product");
        }
      } else {
        print("Error: ${response.statusCode}");
      }
    } catch (e) {
      print("Exception: $e");
    }
  }

// Future<void> removeProduct(String productId,String productName) async {
//   final String apiUrl = 'http://your-backend-url.com/removeproduct';

//   try {
//     final response = await http.post(
//       Uri.parse(apiUrl),
//       headers: {"Content-Type": "application/json"},
//       body: jsonEncode({"id": productId}),
//     );

//     if (response.statusCode == 200) {
//       final data = jsonDecode(response.body);
//       if (data['success'] == true) {
//         print("Product removed successfully: ${data['name']}");
//       } else {
//         print("Failed to remove product");
//       }
//     } else {
//       print("Error: ${response.statusCode}");
//     }
//   } catch (e) {
//     print("Exception: $e");
//   }
// }

  @override
  void initState() {
    super.initState();
    products = fetchProducts();
    // print(products);
    // Fetch products when the widget is initialized
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Product List'),
      ),
      body: FutureBuilder<List<dynamic>>(
        future: products,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(
                child: CircularProgressIndicator()); // Show loading indicator
          } else if (snapshot.hasError) {
            return Center(
                child: Text('Error: ${snapshot.error}')); // Show error message
          } else if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return Center(child: Text('No products found.'));
          } else {
            // Show the list of products
            List<dynamic> products = snapshot.data!;
            return ListView.builder(
              itemCount: products.length,
              itemBuilder: (context, index) {
                var product = products[index];
                String name = product['name'] ?? 'No Name';
                double price = product['new_price']?.toDouble() ?? 0.0;
                String imageUrl = product['image'] ?? '';

                return Card(
                  margin: EdgeInsets.all(8.0),
                  child: ListTile(
                    leading: imageUrl.isNotEmpty
                        ? Image.network(imageUrl,
                            width: 50, height: 50, fit: BoxFit.cover)
                        : Icon(Icons.image,
                            size: 50), // Show an icon if there's no image
                    title: Text(name),
                    subtitle: Text('₨ ${price.toStringAsFixed(2)}'),
                    trailing: GestureDetector(
                        onTap: () {
                          removeProduct(index, name);
                        },
                        child: Icon(Icons.delete)),
                    onTap: () {
                      // Handle onTap, for example, navigate to product details
                    },
                  ),
                );
              },
            );
          }
        },
      ),
    );
  }
}
