import 'package:flutter/material.dart';

import 'package:row_column/backend/add_product.dart';
import 'package:row_column/pages/front_allProdutc.dart';
import 'package:row_column/pages/home.dart';
import 'package:row_column/pages/splash_screen.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Image Upload Demo',
      routes: {
        '/': (context) => SplashScreen(),
        '/add_product': (context) => ImageUploadScreen(),
        '/list_product': (context) => ProductListScreen()
      },
      debugShowCheckedModeBanner: false,
    );
  }
}

// class ImageUploadScreen extends StatefulWidget {
//   @override
//   _ImageUploadScreenState createState() => _ImageUploadScreenState();
// }

// class _ImageUploadScreenState extends State<ImageUploadScreen> {
//   File? _image;
//   String? _responseMessage;

//   final ImagePicker _picker = ImagePicker();
//   final Dio _dio = Dio(); // Dio instance for HTTP requests

//   // Method to pick an image from the gallery
//   Future<void> _pickImage() async {
//     final pickedFile = await _picker.pickImage(source: ImageSource.gallery);
//     if (pickedFile != null) {
//       setState(() {
//         _image = File(pickedFile.path);
//       });
//     }
//   }

//   // Method to upload the selected image using Dio
//   Future<void> _uploadImage() async {
//     if (_image == null) {
//       setState(() {
//         _responseMessage = 'Please select an image first!';
//       });
//       return;
//     }

//     // API URL
//     const String apiUrl = 'http://localhost:4000/upload';

//     try {
//       // Create a FormData object with the image file
//       FormData formData = FormData.fromMap({
//         'product':
//             await MultipartFile.fromFile(_image!.path),
//       });

//       // Make the POST request with Dio
//       var response = await _dio.post(apiUrl, data: formData);
//       print(formData);

//       // Check the response status
//       if (response.statusCode == 200) {
//         setState(() {
//           _responseMessage = 'Upload Successful: ${response.data}';
//         });
//       } else {
//         setState(() {
//           _responseMessage = 'Upload Failed: ${response.statusCode}';
//         });
//       }
//     } catch (e) {
//       setState(() {
//         _responseMessage = 'Error: $e';
//       });
//     }
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text('Image Upload Demo'),
//       ),
//       body: Padding(
//         padding: const EdgeInsets.all(16.0),
//         child: Column(
//           mainAxisAlignment: MainAxisAlignment.center,
//           crossAxisAlignment: CrossAxisAlignment.center,
//           children: [
//             _image == null ? Text('No image selected.') : Image.file(_image!),
//             SizedBox(height: 20),
//             ElevatedButton(
//               onPressed: _pickImage,
//               child: Text('Select Image'),
//             ),
//             SizedBox(height: 20),
//             ElevatedButton(
//               onPressed: _uploadImage,
//               child: Text('Upload Image'),
//             ),
//             SizedBox(height: 20),
//             _responseMessage == null
//                 ? Container()
//                 : Text(
//                     _responseMessage!,
//                     textAlign: TextAlign.center,
//                     style: TextStyle(fontSize: 16, color: Colors.blue),
//                   ),
//           ],
//         ),
//       ),
//     );
//   }
// }
