import 'dart:collection';
import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:row_column/model/product_modal.dart';

class CartProvider extends ChangeNotifier {
  final List<Product> _cartItems = [];

  UnmodifiableListView get cartItems => UnmodifiableListView(_cartItems);

  double get price => _cartItems.fold<double>(
      0.0, (previousValue, element) => previousValue += element.price);

  // Add Item
  void addItem(Product product) {
    _cartItems.add(product);
    notifyListeners();
    log("Item Added");
  }

  // Reset Cart
  void reset() {
    _cartItems.clear();
    notifyListeners();
  }
}
